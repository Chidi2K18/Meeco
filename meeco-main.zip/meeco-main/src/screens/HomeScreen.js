import * as Location from 'expo-location'
import React, { useEffect, useState } from 'react'
import { ActivityIndicator, SafeAreaView, StatusBar, View } from 'react-native'
import NearestShopsList from '../components/NearestShopsList'

export default function HomeScreen({ navigation }) {
  const [location, setLocation] = useState(null)
  const [errorMsg, setErrorMsg] = useState(null)

  useEffect(() => {
    ;(async () => {
      let { status } = await Location.requestPermissionsAsync()
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied')
        return
      }

      let location = await Location.getCurrentPositionAsync({})
      setLocation(location)
      console.log(location) // For testing - Outputs geo info to the console                            !!
    })()
  }, [])

  if (!location && !errorMsg) {
    return (
      <View>
        <ActivityIndicator />
      </View>
    )
  }

  return (
    <SafeAreaView>
      <StatusBar style="auto" />
      <NearestShopsList location={location} />
    </SafeAreaView>
  )
}
