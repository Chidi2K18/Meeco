import { Ionicons } from '@expo/vector-icons'
import React, { useState } from 'react'
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  TextInput,
  View,
} from 'react-native'
import Shop from '../components/Shop'
import ShopList from '../components/ShopList'

let timeout = null

export default function SearchScreen() {
  const [searchResults, setSearchResults] = useState([])

  const queryChanged = val => {
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(() => {
      search(val)
    }, 400)
  }

  const search = async query => {
    if (query === '') {
      setSearchResults([])
      return
    }
    try {
      // Fetch array of shops from database
      const url = `https://meecoapp.com/api/v1/shops/search/${query}`
      const res = await fetch(url)
      const data = await res.json()
      setSearchResults(data.shops || [])
    } catch (err) {
      console.error(err)
    }
  }

  if (searchResults.length) {
    resultList = (
      <View>
        <ScrollView contentContainerStyle={styles.scrollView}>
          {searchResults.map(shop => (
            <Shop
              key={shop._id}
              shop={shop}
              width={'auto'}
              showDistance={true}
            />
          ))}
        </ScrollView>
      </View>
    )
  } else {
    resultList = null
  }

  return (
    <SafeAreaView>
      <StatusBar style="auto" />
      <ScrollView>
        <View style={styles.container}>
          <Ionicons
            style={styles.searchIcon}
            name="ios-search"
            size={20}
            color="green"
          />
          <TextInput
            placeholder="Coffee, Kids Clothes, Nike"
            style={styles.searchInput}
            onChangeText={val => {
              queryChanged(val.trim())
            }}
          />
        </View>
        <View>{resultList ? resultList : <ShopList />}</View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  searchInput: {
    fontSize: 16,
    marginLeft: 10,
    width: '100%',
  },
  container: {
    marginHorizontal: 16,
    marginTop: 18,
    height: 50,
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 30,
    elevation: 2,
  },
  searchIcon: {
    textAlignVertical: 'center',
    marginLeft: 20,
  },
})
