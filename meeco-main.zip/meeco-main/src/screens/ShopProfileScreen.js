import { format } from 'date-fns'
import { LinearGradient } from 'expo-linear-gradient'
import React from 'react'
import {
  Dimensions,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native'
import MapView, { Marker } from 'react-native-maps'
import ShopRating from '../components/ShopRating'
import { colors } from '../theme'

export default function ShopProfileScreen({ route, navigation }) {
  const { shop } = route.params
  var date = new Date() // date + time
  var weekday = date.getDay()

  var closingTime
  var openingTime

  switch (
    weekday // assign open/close times based on weekday
  ) {
    case 1:
      closingTime = new Date(shop.openingTimes.mon[1] * 1000)
      openingTime = new Date(shop.openingTimes.mon[0] * 1000)
      break
    case 2:
      closingTime = new Date(shop.openingTimes.tue[1] * 1000)
      openingTime = new Date(shop.openingTimes.tue[0] * 1000)
      break
    case 3:
      closingTime = new Date(shop.openingTimes.wed[1] * 1000)
      openingTime = new Date(shop.openingTimes.wed[0] * 1000)
      break
    case 4:
      closingTime = new Date(shop.openingTimes.thu[1] * 1000)
      openingTime = new Date(shop.openingTimes.thu[0] * 1000)
      break
    case 5:
      closingTime = new Date(shop.openingTimes.fri[1] * 1000)
      openingTime = new Date(shop.openingTimes.fri[0] * 1000)
      break
    case 6:
      closingTime = new Date(shop.openingTimes.sat[1] * 1000)
      openingTime = new Date(shop.openingTimes.sat[0] * 1000)
      break
    case 7:
      closingTime = new Date(shop.openingTimes.sun[1] * 1000)
      openingTime = new Date(shop.openingTimes.sun[0] * 1000)
      break
  }
  var midnightToday = new Date() // today at midnight
  midnightToday.setHours(0, 0, 0, 0)
  var closingTimeMaths = closingTime - 1621209600000 // take away date portion
  var openingTimeMaths = openingTime - 1621209600000 // take away date portion
  var time = date - midnightToday // take away date portion
  //const time = 0; // use to test closing times - delete

  return (
    <ScrollView style={styles.container}>
      {/* Hero image */}
      <Image
        style={styles.hero}
        source={{ uri: `https://meecoapp.com/images/${shop.hero}` }}
      />
      <LinearGradient
        // Background Linear Gradient
        colors={['transparent', 'rgba(56,56,56,0)', 'rgba(0,0,0,1)']}
        style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 200 }}
      />

      {/* Category */}
      <Text style={styles.category}>{shop.category}</Text>

      {/* Logo */}
      <Image
        style={styles.logo}
        source={{ uri: `https://meecoapp.com/images/${shop.logo}` }}
      />

      {/* Shop Name */}
      <Text style={styles.title}>{shop.name}</Text>

      {/* Opening times */}
      <View>
        {time > openingTimeMaths && time < closingTimeMaths ? (
          <Text style={styles.openingTime}>
            {'open '}
            <Text style={{ color: '#000' }}>
              until {String(format(closingTime, 'H:mma'))}
            </Text>
          </Text>
        ) : (
          <Text style={styles.openingTimeClosed}>
            {'closed '}
            <Text style={{ color: '#000' }}>
              - opens at {String(format(openingTime, 'H:mma'))}
            </Text>
          </Text>
        )}
      </View>

      {/* Description */}
      <Text style={styles.description}>{shop.description}</Text>

      {/* Rating */}
      <ShopRating rating={shop.rating} />

      {/* Badges */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ marginTop: 8 }}
        contentContainerStyle={{ paddingHorizontal: 10 }}
      >
        <View style={styles.badges}>
          <Image
            style={styles.badgeImage}
            source={require('../images/cup.png')}
          />
          <Text style={styles.badgeText}>Bans Single Use Cups</Text>
        </View>
        <View style={styles.badges}>
          <Image
            style={styles.badgeImage}
            source={require('../images/ethicalTea.jpg')}
          />
          <Text style={styles.badgeText}>Ethical Tea Partnership</Text>
        </View>
        <View style={styles.badges}>
          <Image
            style={styles.badgeImage}
            source={require('../images/greenEnergy.png')}
          />
          <Text style={styles.badgeText}>Green Energy</Text>
        </View>
      </ScrollView>

      {/* Location */}
      <Text style={styles.sectionTitle}>Location</Text>
      <MapView
        style={styles.map}
        region={{
          ...shop.location,
          latitudeDelta: 0.0025,
          longitudeDelta: 0.0025,
        }}
      >
        <Marker
          coordinate={shop.location}
          title={shop.title}
          description={shop.description}
        />
      </MapView>
    </ScrollView>
  )
}

const logoSize = 125

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    backgroundColor: colors.background,
  },
  hero: {
    width: '100%',
    height: 200,
    zIndex: 0,
    // resizeMode: "contain",
  },
  category: {
    zIndex: 1,
    color: 'white',
    // marginTop: -30,
    marginBottom: 0,
    // marginLeft: 32,
    position: 'absolute',
    top: 170,
    left: 32,
    fontSize: 13,
    fontStyle: 'italic',
    textTransform: 'capitalize',
  },
  logo: {
    width: logoSize,
    height: logoSize,
    borderRadius: logoSize / 2,
    // borderColor: '#A2A2A2',
    // borderWidth: 1,
    zIndex: 1,
    position: 'relative',
    marginTop: -(logoSize / 2),
    alignSelf: 'center',
  },
  title: {
    fontStyle: 'normal',
    fontWeight: 'bold',
    fontSize: 28,
    alignSelf: 'center',
    marginTop: 32,
  },
  openingTime: {
    fontSize: 16,
    alignSelf: 'center',
    marginTop: 16,
    color: '#007F5F',
    textTransform: 'capitalize',
  },
  openingTimeClosed: {
    fontSize: 16,
    alignSelf: 'center',
    marginTop: 16,
    color: '#FF0000',
    textTransform: 'capitalize',
  },
  description: {
    marginHorizontal: 30,
    marginTop: 24,
    alignSelf: 'center',
    fontSize: 15,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  badges: {
    backgroundColor: 'white',
    width: 150,
    height: 175,
    marginHorizontal: 10,
    marginBottom: 16,
    marginTop: 8,
    borderRadius: 18,
    elevation: 3,
    shadowOffset: { width: 0, height: 3 },
    shadowColor: 'black',
    shadowOpacity: 0.16,
    shadowRadius: 18,
    padding: 8,
    justifyContent: 'center',
  },
  badgeText: {
    marginTop: '5%',
    color: '#007F5F',
    textAlign: 'center',
    padding: 8,
  },
  badgeImage: {
    maxWidth: 60,
    maxHeight: 60,
    alignSelf: 'center',
    marginTop: 10,
    resizeMode: 'contain',
  },
  sectionTitle: {
    fontStyle: 'italic',
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 20,
    marginTop: 24,
  },
  map: {
    marginTop: 16,
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').width,
  },
})
