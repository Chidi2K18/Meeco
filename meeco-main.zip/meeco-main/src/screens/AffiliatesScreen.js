import React, { useState } from 'react'
import {
  Image,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native'
import { colors } from '../theme'
export default function AffiliatesScreen({ route, navigation }) {
  const [modalVisible, setModalVisible] = useState(false)

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      {/* Header */}
      <Text style={styles.heading}>Shopping online?</Text>
      <Text style={styles.description}>
        Use these links before shopping online to support our app!
      </Text>

      <ScrollView contentContainerStyle={{ paddingBottom: 10 }}>
        {/* How does it work button */}
        <Modal
          animationType="fade"
          transparent={false}
          visible={modalVisible}
          hardwareAccelerated={true}
          onRequestClose={() => {
            setModalVisible(!modalVisible)
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>
                When you click one of our affiliate links before making a
                purchase on that website, we earn a small commission from that
                sale. That revenue goes to maintaining and expanding our app, so
                more people can shop sustainably.
              </Text>
              <Pressable
                style={[styles.button, styles.buttonClose]}
                onPress={() => setModalVisible(!modalVisible)}
              >
                <Text style={styles.modalClose}>OK</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
        <Pressable onPress={() => setModalVisible(true)}>
          <View style={styles.button}>
            <Text style={styles.howDoesItWork}>How does it work?</Text>
          </View>
        </Pressable>

        {/*  Affiliates tabs */}

        {/* Affiliates container Amazon*/}
        <View style={styles.card}>
          <Image
            style={styles.logo}
            source={require('../images/AmazonIcon.png')}
          />
          <Text style={styles.linkName}>Amazon</Text>
          <Image
            style={styles.open}
            source={require('../images/round_open_in_new_black_24dp.png')}
          />
        </View>
        <View style={styles.card}>
          <Image style={styles.logo} source={require('../images/argos.png')} />
          <Text style={styles.linkName}>Argos</Text>
          <Image
            style={styles.open}
            source={require('../images/round_open_in_new_black_24dp.png')}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#55A630',
    alignSelf: 'center',
    borderRadius: 50,
    marginTop: 30,
    padding: 10,
    elevation: 3,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
  },
  modalText: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 24,
  },
  modalClose: {
    paddingHorizontal: 10,
    minWidth: 100,
    textAlign: 'center',
    fontSize: 18,
    color: 'white',
  },
  container: {
    flexDirection: 'column',
    backgroundColor: colors.background,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 18,
    marginTop: 30,
    marginHorizontal: 30,
    elevation: 3,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  logo: {
    height: 40,
    width: 40,
    margin: 18,
  },
  linkName: {
    fontSize: 18,
  },
  open: {
    // flexGrow: 1,
    marginLeft: 'auto',
    marginRight: 24,
    height: 24,
    width: 24,
  },
  // affiliatescontainer: {
  //   flexDirection: 'row',
  //   width: '70%',
  //   height: 70,
  //   justifyContent: 'space-between',
  //   alignSelf: 'center',
  //   margin: 20,
  // },
  // headeraffiliates: {
  //   marginTop: 30,
  //   fontSize: 20,
  //   fontWeight: 'bold',
  //   color: 'black',
  //   alignSelf: 'center',
  // },
  // description: {
  //   color: 'black',
  //   alignSelf: 'center',
  //   width: 310,
  // },
  heading: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
    marginTop: 32,
  },
  description: {
    color: 'black',
    fontSize: 18,
    textAlign: 'center',
    width: '70%',
    alignSelf: 'center',
    marginTop: 28,
    lineHeight: 24,
  },
  howDoesItWork: {
    color: 'white',
    paddingHorizontal: 10,
    paddingVertical: 2,
    fontSize: 16,
  },
})
