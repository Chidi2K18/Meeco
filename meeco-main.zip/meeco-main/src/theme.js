export const colors = {
  // background: '#FFFAF5',
  // background: '#fcfcfc',
  // background: '#f1f1f1',
  background: '#f9f9ff',
  logoGreen: '#2b9348',
  textGreen: 'seagreen',
}
