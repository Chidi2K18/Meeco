import React, { useEffect, useState } from 'react'
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native'
import Shop from './Shop'

export default function ShopList() {
  // Replace with an API request to get list of shops from database
  // const shops = [
  //   { id: 1, name: 'Nike' },
  //   { id: 2, name: 'Patagonia', rating: 325, isopen: 'closed', timeToClose: "17:30" },
  //   { id: 3, name: 'Boston tea party' },
  // ]

  const [shops, setShops] = useState([])

  useEffect(() => {
    async function getShops() {
      try {
        // Fetch array of shops from database
        const res = await fetch(`https://meecoapp.com/api/v1/shops`)
        const data = await res.json()
        setShops(data.shops || [])
      } catch (err) {
        console.error(err)
      }
    }

    getShops()
  }, [])

  // Show loading spinner if no shops loaded
  if (!shops.length) {
    return (
      <View>
        <ActivityIndicator />
      </View>
    )
  }

  return (
    <View>
      <Text style={styles.heading}>Promoted</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.container}
        contentContainerStyle={{ paddingHorizontal: 8 }}
      >
        {shops.map(shop => (
          <Shop key={shop._id} shop={shop} />
        ))}
      </ScrollView>
      <Text style={styles.heading}>Nearby</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.container}
        contentContainerStyle={{ paddingHorizontal: 8 }}
      >
        {shops.map(shop => (
          <Shop key={shop._id} shop={shop} />
        ))}
      </ScrollView>
    </View>
  )
}
const styles = StyleSheet.create({
  heading: {
    fontStyle: 'italic',
    fontWeight: 'bold',
    fontSize: 16,
    padding: 8,
    margin: 8,
    marginTop: 16,
  },
  container: {
    flexDirection: 'row',
  },
})
