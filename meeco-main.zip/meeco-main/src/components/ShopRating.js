import React from 'react'
import { Image, StyleSheet, Text, View } from 'react-native'

export default function ShopRating({ rating, ...props }) {
  return (
    <View style={[styles.rating, props.style]}>
      <Image
        style={{ width: 21, height: 14 }}
        source={require('../images/leaf.png')}
      />
      <Text style={{ fontSize: 16 }}>{rating}</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  rating: {
    backgroundColor: 'white',
    width: 70,
    height: 30,
    marginLeft: 20,
    marginTop: 40,
    borderRadius: 15,
    padding: 8,
    alignItems: 'center',
    justifyContent: 'space-evenly',
    flexDirection: 'row',
    elevation: 2,
  },
})
