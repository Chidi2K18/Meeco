import React, { useEffect, useState } from 'react'
import { ActivityIndicator, ScrollView, StyleSheet, View } from 'react-native'
import Shop from './Shop'

export default function NearestShopsList({ location }) {
  const [shops, setShops] = useState([])

  useEffect(() => {
    async function getShops() {
      try {
        // Fetch array of shops from database
        const url = location
          ? `https://meecoapp.com/api/v1/shops/nearby/${location.coords.latitude}/${location.coords.longitude}`
          : `https://meecoapp.com/api/v1/shops/`
        const res = await fetch(url)
        const data = await res.json()
        setShops(data.shops || [])
      } catch (err) {
        console.error(err)
      }
    }

    getShops()
  }, [])

  // Show loading spinner if no shops loaded
  if (!shops.length) {
    return (
      <View>
        <ActivityIndicator />
      </View>
    )
  }

  return (
    <View>
      <ScrollView contentContainerStyle={styles.scrollView}>
        {shops.map(shop => (
          <Shop key={shop._id} shop={shop} width={'auto'} showDistance={true} />
        ))}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  scrollView: {
    paddingVertical: 16,
  },
})
