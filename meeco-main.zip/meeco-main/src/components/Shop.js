import { useNavigation } from '@react-navigation/core'
import { LinearGradient } from 'expo-linear-gradient'
import React from 'react'
import { Image, StyleSheet, Text } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import ShopRating from './ShopRating'

const Shop = ({ shop, showDistance, ...params }) => {
  const navigation = useNavigation()

  return (
    <TouchableOpacity
      style={[styles.shop, { width: params.width || 180 }]}
      activeOpacity={0.8}
      onPress={() => {
        navigation.navigate('Shop', { shop })
      }}
    >
      {/* change buttons into clickable images */}
      <Image
        style={styles.image}
        source={{ uri: `https://meecoapp.com/images/${shop.hero}` }}
      />

      <LinearGradient
        style={styles.gradient}
        colors={['transparent', 'rgba(0,0,0,0)', 'rgba(0,0,0,1)']}
      />

      <ShopRating style={styles.rating} rating={shop.rating} />

      <Text style={styles.category}>{shop.category}</Text>
      <Text style={styles.name}>{shop.name}</Text>

      {showDistance && shop.location.distance && (
        <Text style={styles.distance}>{shop.location.distance}m away</Text>
      )}
    </TouchableOpacity>
  )
}

export default Shop

const styles = StyleSheet.create({
  shop: {
    marginHorizontal: 8,
    marginBottom: 16,
    marginTop: 8,
    height: 225,
    borderRadius: 18,
    elevation: 6,
    overflow: 'hidden',
  },
  image: {
    resizeMode: 'cover',
    minWidth: '100%',
    minHeight: '100%',
  },
  gradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 225,
  },
  category: {
    position: 'absolute',
    fontSize: 14,
    fontStyle: 'italic',
    color: 'white',
    left: 14,
    bottom: 42,
    textTransform: 'capitalize',
  },
  name: {
    position: 'absolute',
    fontSize: 19,
    fontWeight: 'bold',
    color: 'white',
    left: 14,
    bottom: 14,
  },
  distance: {
    position: 'absolute',
    fontSize: 14,
    fontStyle: 'italic',
    color: 'white',
    bottom: 16,
    right: 14,
  },
  rating: {
    position: 'absolute',
    marginTop: 0,
    top: 14,
    right: 14,
    zIndex: 100,
  },
})
