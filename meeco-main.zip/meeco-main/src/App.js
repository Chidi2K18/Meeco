import { Ionicons } from '@expo/vector-icons'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { DefaultTheme, NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'
import React from 'react'
import AffiliatesScreen from './screens/AffiliatesScreen'
import HomeScreen from './screens/HomeScreen'
import SearchScreen from './screens/SearchScreen'
import ShopProfileScreen from './screens/ShopProfileScreen'
import { colors } from './theme'

const Tab = createBottomTabNavigator()
const Stack = createStackNavigator()

const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: 'red',
    background: colors.background,
  },
}

export default function App() {
  return (
    <NavigationContainer theme={MyTheme}>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline'
            } else if (route.name === 'Search') {
              iconName = focused ? 'search' : 'search-outline'
            } else if (route.name === 'Affiliates') {
              iconName = focused ? 'globe-outline' : 'globe-outline'
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />
          },
        })}
        tabBarOptions={{
          activeTintColor: colors.textGreen,
          inactiveTintColor: 'gray',
          showLabel: false,
          style: {
            backgroundColor: colors.background,
          },
        }}
      >
        <Tab.Screen name="Home" component={HomeNavWrapper} />
        <Tab.Screen name="Search" component={SearchNavWrapper} />
        <Tab.Screen name="Affiliates" component={AffiliatesScreenWrapper} />
      </Tab.Navigator>
    </NavigationContainer>
  )
}

const headerOptions = {
  headerShown: true,
  headerTitle: 'meeco',
  headerTitleAlign: 'center',
  headerTitleContainerStyle: { textAlign: 'center' },
  headerTitleStyle: { color: colors.logoGreen, fontSize: 24 },
}

// Wrap the home page in a stack navigator so we can navigate to the shop profile page from home screen
function HomeNavWrapper() {
  return (
    <Stack.Navigator
      initialRouteName="Home"
      headerMode="screen"
      screenOptions={{
        headerTintColor: 'black',
        headerStyle: {
          backgroundColor: colors.background,
        },
      }}
    >
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={headerOptions}
      />
      <Stack.Screen
        name="Shop"
        component={ShopProfileScreen}
        options={({ route }) => ({ title: route.params.shop.name })}
      />
    </Stack.Navigator>
  )
}
function SearchNavWrapper() {
  return (
    <Stack.Navigator
      initialRouteName="Search"
      headerMode="screen"
      screenOptions={{
        headerTintColor: 'black',
        headerStyle: {
          backgroundColor: colors.background,
        },
      }}
    >
      <Stack.Screen
        name="Search"
        component={SearchScreen}
        options={headerOptions}
      />
      <Stack.Screen
        name="Shop"
        component={ShopProfileScreen}
        options={({ route }) => ({ title: route.params.shop.name })}
      />
    </Stack.Navigator>
  )
}
function AffiliatesScreenWrapper() {
  return (
    <Stack.Navigator
      initialRouteName="Affiliates"
      headerMode="screen"
      screenOptions={{
        headerTintColor: 'black',
        headerStyle: {
          backgroundColor: colors.background,
        },
      }}
    >
      <Stack.Screen
        name="Affiliates"
        component={AffiliatesScreen}
        options={headerOptions}
      />
    </Stack.Navigator>
  )
}
