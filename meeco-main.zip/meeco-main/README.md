#

# meeco

## Getting set up

1. Install Node.js
   - https://nodejs.org/en/
2. Install GitHub Desktop
   - https://desktop.github.com/
3. Watch a bit of this video explaining what Expo/React Native is
   - https://www.youtube.com/watch?v=0-S5a0eXPoc&t=180s
4. Install Expo
   - https://docs.expo.io/get-started/installation/
   - `npm install --global expo-cli`
5. Clone this repository with GitHub Desktop
6. Run `npm install` within the reposity (in the 'meeco' folder)
7. Run `expo start`

#

# Useful resources

## React Native docs

https://reactnative.dev/docs/getting-started

## React Navigation

Used to navigate between pages in the app  
https://reactnavigation.org/docs/hello-react-navigation
