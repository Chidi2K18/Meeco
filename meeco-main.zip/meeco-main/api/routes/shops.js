const express = require('express')
const { getShops, createShop, getNearbyShops } = require('../controllers/shops')

const router = express.Router()

router.route('/').get(getShops).post(createShop)
router.route('/nearby/:latitude/:longitude').get(getNearbyShops)

module.exports = router
