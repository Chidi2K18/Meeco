const mongoose = require('mongoose')
require('mongoose-type-url')

const ShopSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: [28, 'Title cannot be more than 28 characters'],
  },
  description: {
    type: String,
    maxlength: [256, 'Description cannot be more than 256 characters'],
  },
  category: {
    type: String,
    enum: ['cafe', 'clothes', 'footwear'],
    required: true,
  },
  rating: {
    type: Number,
    require: true,
  },
  openingTimes: {
    mon: [Number],
    tue: [Number],
    wed: [Number],
    thu: [Number],
    fri: [Number],
    sat: [Number],
    sun: [Number],
  },
  location: {
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
		distance: {type: Number, required: false}
  },
  logo: String,
  hero: String,
})

module.exports = mongoose.model('Shops', ShopSchema)
