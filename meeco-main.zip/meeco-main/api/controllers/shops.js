const Shop = require('../models/Shop')
const asyncHandler = require('../middleware/async')

exports.getShops = asyncHandler(async (req, res, next) => {
  const shops = await Shop.find()

  res.status(200).json({ success: true, shops })
})

exports.createShop = asyncHandler(async (req, res, next) => {
  const shop = new Shop(req.body)

  await shop.save()

  res.status(201).json({ success: true, shop })
})

exports.getNearbyShops = asyncHandler(async (req, res, next) => {
  let shops = await Shop.find()

  const { latitude, longitude } = req.params

  shops = shops.map(shop => {
    const distance = calcDistance(
      latitude,
      longitude,
      shop.location.latitude,
      shop.location.longitude
    )
    shop.location.distance = Math.round(distance)
    return shop
  })

  shops = shops.sort((a, b) => a.location.distance - b.location.distance)

  res.status(200).json({ success: true, shops })
})

// REFERENCE: https://www.movable-type.co.uk/scripts/latlong.html
function calcDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3 // metres
  const φ1 = (lat1 * Math.PI) / 180 // φ, λ in radians
  const φ2 = (lat2 * Math.PI) / 180
  const Δφ = ((lat2 - lat1) * Math.PI) / 180
  const Δλ = ((lon2 - lon1) * Math.PI) / 180

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

  const d = R * c // in metres
  return d
}
